<?php
/**
 * Plugin Name: Automotive Multi Widget
 * Description: Widget com tema de automóveis, formulário de cadastro, SMTP configurável, upload de imagem e painel administrativo.
 * Version: 1.1
 * Author: Seu Nome
 * Requires at least: 6.0
 * Tested up to: 6.8.2
 */

if (!defined('ABSPATH')) exit;

define('AUTOMOTIVE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AUTOMOTIVE_PLUGIN_URL', plugin_dir_url(__FILE__));

// Carrega classes
require_once AUTOMOTIVE_PLUGIN_DIR . 'includes/class-automotive-widget.php';
require_once AUTOMOTIVE_PLUGIN_DIR . 'includes/class-smtp-handler.php';
require_once AUTOMOTIVE_PLUGIN_DIR . 'includes/admin/class-automotive-admin.php';

// Hooks
add_action('widgets_init', function() {
    register_widget('Automotive_Multi_Widget');
});

add_action('admin_menu', ['Automotive_Admin', 'add_admin_menu']);
add_action('admin_init', ['Automotive_Admin', 'settings_init']);

register_activation_hook(__FILE__, 'automotive_create_table');
function automotive_create_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'automotive_registrations';
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(100) NOT NULL,
        email varchar(100) NOT NULL,
        phone varchar(20) NOT NULL,
        image_url text,
        registration_date datetime DEFAULT CURRENT_TIMESTAMP,
        password_hash varchar(255) NOT NULL,
        code varchar(50) NOT NULL,
        address text NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY email (email)
    ) $charset;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('automotive-style', AUTOMOTIVE_PLUGIN_URL . 'includes/assets/style.css', [], '1.1');
});