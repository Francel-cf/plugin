automotive-multi-widget/
├── automotive-multi-widget.php
├── includes/
│   ├── class-automotive-widget.php
│   ├── class-smtp-handler.php
│   ├── assets/
│   │   └── style.css
│   └── admin/
│       └── class-automotive-admin.php
└── readme.txt (opcional)