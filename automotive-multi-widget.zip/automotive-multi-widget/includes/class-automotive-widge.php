<?php
class Automotive_Multi_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'automotive_multi_widget',
            __('Automotive Registration Widget', 'automotive'),
            ['description' => __('Formulário de cadastro com tema automotivo', 'automotive')]
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];

        $title = apply_filters('widget_title', $instance['title'] ?? 'Cadastro de Veículos');
        echo $args['before_title'] . $title . $args['after_title'];

        // Cabeçalho
        echo '<div class="automotive-header">';
        echo '<h2>🚗 Bem-vindo à Concessionária Premium!</h2>';
        echo '</div>';

        // Formulário
        echo '<form method="post" enctype="multipart/form-data" class="automotive-form">';
        wp_nonce_field('automotive_form_action', 'automotive_nonce');

        echo '<label>Nome: <input type="text" name="name" required></label>';
        echo '<label>E-mail: <input type="email" name="email" required></label>';
        echo '<label>Telefone: <input type="tel" name="phone" required></label>';
        echo '<label>Imagem (veículo ou documento): <input type="file" name="image" accept="image/*"></label>';
        echo '<label>Senha: <input type="password" name="password" required></label>';
        echo '<label>Código de Acesso: <input type="text" name="code" required></label>';
        echo '<label>Endereço Residencial: <textarea name="address" required></textarea></label>';

        echo '<input type="submit" name="automotive_submit" value="Cadastrar">';
        echo '</form>';

        // Processa envio
        if (isset($_POST['automotive_submit']) && wp_verify_nonce($_POST['automotive_nonce'], 'automotive_form_action')) {
            $this->handle_submission();
        }

        // Rodapé
        echo '<div class="automotive-footer">';
        echo '<p>© ' . date('Y') . ' Concessionária Premium. Todos os direitos reservados.</p>';
        echo '</div>';

        echo $args['after_widget'];
    }

    private function handle_submission() {
        global $wpdb;

        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $address = sanitize_textarea_field($_POST['address']);
        $code = sanitize_text_field($_POST['code']);
        $password_hash = wp_hash_password($_POST['password']);

        // Upload de imagem
        $image_url = '';
        if (!empty($_FILES['image']['name'])) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            $upload = wp_handle_upload($_FILES['image'], ['test_form' => false]);
            if (!isset($upload['error'])) {
                $image_url = $upload['url'];
            }
        }

        // Salva no banco
        $table = $wpdb->prefix . 'automotive_registrations';
        $wpdb->insert($table, [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'image_url' => $image_url,
            'password_hash' => $password_hash,
            'code' => $code,
            'address' => $address
        ]);

        // Envia e-mail via SMTP
        $smtp = new Automotive_SMTP_Handler();
        $smtp->send_email($email, 'Cadastro Confirmado', "Olá $name, seu cadastro foi realizado com sucesso!");

        echo '<div class="automotive-success">✅ Cadastro realizado com sucesso! Um e-mail foi enviado para você.</div>';
    }

    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : 'Cadastro de Veículos';
        echo '<p><label>Título: <input class="widefat" name="' . $this->get_field_name('title') . '" type="text" value="' . esc_attr($title) . '"></label></p>';
    }

    public function update($new_instance, $old_instance) {
        $instance = [];
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        return $instance;
    }
}