<?php
class Automotive_SMTP_Handler {

    public function send_email($to, $subject, $message, $reply_to = null) {
        $host = get_option('automotive_smtp_host');
        $port = get_option('automotive_smtp_port', 587);
        $user = get_option('automotive_smtp_user');
        $pass = get_option('automotive_smtp_pass');
        $from = get_option('automotive_smtp_from') ?: $user;

        if (!$host || !$user || !$pass) {
            // Fallback para wp_mail padrão (sem SMTP)
            return wp_mail($to, $subject, $message, $reply_to ? "Reply-To: $reply_to" : '');
        }

        add_action('phpmailer_init', function($phpmailer) use ($host, $port, $user, $pass, $from) {
            $phpmailer->isSMTP();
            $phpmailer->Host       = $host;
            $phpmailer->SMTPAuth   = true;
            $phpmailer->Port       = $port;
            $phpmailer->Username   = $user;
            $phpmailer->Password   = $pass;
            $phpmailer->SMTPSecure = $port == 465 ? 'ssl' : 'tls';
            $phpmailer->From       = $from;
            $phpmailer->FromName   = 'Concessionária Premium';
        });

        $headers = $reply_to ? ["Reply-To: $reply_to"] : [];
        return wp_mail($to, $subject, $message, $headers);
    }
}