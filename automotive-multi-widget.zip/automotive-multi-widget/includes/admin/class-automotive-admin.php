<?php
class Automotive_Admin {

    public static function add_admin_menu() {
        add_menu_page(
            'Automotive Cadastros',
            'Automotive',
            'manage_options',
            'automotive-dashboard',
            [__CLASS__, 'list_registrations'],
            'dashicons-car',
            30
        );

        add_submenu_page(
            'automotive-dashboard',
            'Configurações SMTP',
            'SMTP',
            'manage_options',
            'automotive-smtp-settings',
            [__CLASS__, 'smtp_settings_page']
        );
    }

    public static function settings_init() {
        register_setting('automotive_smtp', 'automotive_smtp_host');
        register_setting('automotive_smtp', 'automotive_smtp_port');
        register_setting('automotive_smtp', 'automotive_smtp_user');
        register_setting('automotive_smtp', 'automotive_smtp_pass');
        register_setting('automotive_smtp', 'automotive_smtp_from');
    }

    public static function smtp_settings_page() {
        ?>
        <div class="wrap">
            <h1>Configurações SMTP - Automotive</h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('automotive_smtp');
                do_settings_sections('automotive_smtp');
                ?>
                <table class="form-table">
                    <tr>
                        <th>Host SMTP</th>
                        <td><input type="text" name="automotive_smtp_host" value="<?php echo esc_attr(get_option('automotive_smtp_host')); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th>Porta</th>
                        <td><input type="number" name="automotive_smtp_port" value="<?php echo esc_attr(get_option('automotive_smtp_port', 587)); ?>" class="small-text" /></td>
                    </tr>
                    <tr>
                        <th>Usuário (e-mail)</th>
                        <td><input type="email" name="automotive_smtp_user" value="<?php echo esc_attr(get_option('automotive_smtp_user')); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th>Senha</th>
                        <td><input type="password" name="automotive_smtp_pass" value="<?php echo esc_attr(get_option('automotive_smtp_pass')); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th>E-mail de envio</th>
                        <td><input type="email" name="automotive_smtp_from" value="<?php echo esc_attr(get_option('automotive_smtp_from')); ?>" class="regular-text" /></td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public static function list_registrations() {
        global $wpdb;
        $table = $wpdb->prefix . 'automotive_registrations';
        $results = $wpdb->get_results("SELECT * FROM $table ORDER BY registration_date DESC");

        echo '<div class="wrap"><h1>Cadastros Recebidos</h1>';
        if ($results) {
            echo '<table class="wp-list-table widefat fixed striped">
                    <thead><tr>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Telefone</th>
                        <th>Data</th>
                        <th>Imagem</th>
                    </tr></thead><tbody>';
            foreach ($results as $row) {
                echo '<tr>';
                echo "<td>{$row->name}</td>";
                echo "<td>{$row->email}</td>";
                echo "<td>{$row->phone}</td>";
                echo "<td>" . date('d/m/Y H:i', strtotime($row->registration_date)) . "</td>";
                echo "<td>" . ($row->image_url ? '<a href="' . esc_url($row->image_url) . '" target="_blank">Ver</a>' : '—') . "</td>";
                echo '</tr>';
            }
            echo '</tbody></table>';
        } else {
            echo '<p>Nenhum cadastro encontrado.</p>';
        }
        echo '</div>';
    }
}